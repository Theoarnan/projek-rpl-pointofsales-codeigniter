<footer class="main-footer small">
    <strong>Copyright &copy; 2020 <a href="http://github.com/Theornan">Theoarnan</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 3.0.2
    </div>
</footer>